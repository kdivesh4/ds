#include<iostream>
using namespace std;

void ss(int a[], int n)
{
	int i,j,min,temp;
	
	for(i=0;i<n;i++)
	{
		min=i;
		for(j=i+1;j<n;j++)
		if(a[j]<a[min])
		min=j;
		
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;	
	}

}

int main()
{
int n;
cout<<"Enter no. of elemets";
cin>>n;
int a[n];
cout<<"Enter elements";
for(int i=0;i<n;i++)
cin>>a[i];
ss(a,n);
cout<<"Sorted Array";
for(int i=0;i<n;i++)
cout<<a[i]<<" ";
return 0;
}
