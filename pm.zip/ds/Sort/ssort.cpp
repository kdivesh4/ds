#include<iostream>
using namespace std;
void Selection(int arr[],int n)
{
	int i,L,j,temp,count=0;
	for(i=0;i<n;i++)
	{
		L=i;
		for(j=i+1;j<n;j++)
			if(arr[j]<arr[L])
				L=j;
				
		temp=arr[i];
		arr[i]=arr[L];
		arr[L]=temp;
	}
}
int main()
{
	int size;
	cout<<"\n Enter the no. of elements = ";
	cin>>size;
	int ar[size];
	cout<<"\n Enter elements = ";
	for(int i=0;i<size;i++)
		cin>>ar[i];
	Selection(ar,size);
	cout<<"\n Sorted Array = ";
	for(int i=0;i<size;i++)
		cout<<ar[i]<<" ";
	cout<<"\n";
	return 0;
}
			
		
