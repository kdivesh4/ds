#include<iostream>
using namespace std;
int j=1,size;
void swap (int &i,int &j)
{
	int temp;
	temp=i;
	i=j;
	j=temp;
}
		
int partition (int arr[], int low, int high)
{
    int pivot = arr[high];    // pivot
    int i = (low - 1);  
 
    for (int j = low; j <= high- 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++; 
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return (i + 1);
}
void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
     	
        int pi = partition(arr, low, high);
        cout<<"\n After Pass "<<j<<"= ";
        j++;
        for(int i=0;i<size;i++)
        	cout<<" "<<arr[i];
        cout<<"\n";
 
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main()
{
	cout<<"\n Enter the no. of elements = ";
	cin>>size;
	int ar[size];
	cout<<"\n Enter elements = ";
	for(int i=0;i<size;i++)
		cin>>ar[i];
	int low=0,high=size-1;
	quickSort(ar,low,high);
	return 0;
}
