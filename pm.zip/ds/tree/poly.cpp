#include<iostream>
using namespace std;
class Node
{
	public:
	int deg;
	int val;
	Node *next;
	Node()
	{
		deg=0;
		val=0;
		next=NULL;
	}
};
class SLList 
{
	public:
	Node *head;
	Node *tail;
	SLList()
	{
		head=NULL;
		tail=NULL;
	}
	void addtotail(int val,int x)
	{
		Node *n=new Node();
		if(tail==NULL && val!=0)
		{
			head=n;
			tail=n;
			tail->val=val;
			tail->deg=x;
		}
		else if(val!=0)
		{
			tail->next=n;
			tail=n;
			tail->val=val;
			tail->deg=x;
		}
	}
	void display()
	{
		Node *p=new Node();
		p=head;
		cout<<"\n Resultant Polynomial = \n";
		while(p!=NULL)
		{
			cout<<" "<<p->val<<"x("<<p->deg<<")"<<"+";
			p=p->next;
		}
	}
};
void add(Node *head1,Node *head2)
{
	SLList s3;
	Node *p=new Node();
	p=head1;
	Node *q=new Node();
	q=head2;
	while(p!=NULL && q!=NULL)
	{
		if(p->deg>q->deg)
		{
			s3.addtotail(p->val,p->deg);
			p=p->next;
		}
		else if(q->deg>p->deg)
		{
			s3.addtotail(q->val,q->deg);
			q=q->next;
		}
		else if(p->deg==q->deg)
		{
			s3.addtotail((p->val+q->val),p->deg);
			p=p->next;
			q=q->next;
		}
	}
	while(p!=NULL)
	{
		s3.addtotail(p->val,p->deg);
		p=p->next;
	}
	while(q!=NULL)
	{
		s3.addtotail(q->val,q->deg);
		q=q->next;
	}
	s3.display();
}
	
	
int main()
{
	int deg,val;
	cout<<"\n Enter degree of polynomial 1: ";
	cin>>deg;
	SLList s1;
	Node *result;
	for(int i=deg;i>=0;i--)
	{
		cout<<"\n Enter coff. of x("<<i<<"): ";
		cin>>val;
		s1.addtotail(val,i);
	}
	s1.display();
	cout<<"\n Enter degree of polynomial 2: ";
	cin>>deg;
	SLList s2;
	for(int i=deg;i>=0;i--)
	{
		cout<<"\n Enter coff. of x("<<i<<"): ";
		cin>>val;
		s2.addtotail(val,i);
	}
	s2.display();
	add(s1.head,s2.head);
	cout<<"\n";
	return 0;
}
	
		
