#include<iostream>
using namespace std;

class Node
{
public:
	int info;
	Node *next , *prev;
	Node()
	{
		info=0;
		next=NULL;
		prev=NULL;	
	}
};

class odll
{
public:
	Node *head;
	Node *tail;
	odll()
	{
		head=NULL;
		tail=NULL;
	}
	
	void add(int val)
	{
		Node *n = new Node();
                Node *p = new Node();
		n->info=val;
               
		
		if(head=NULL)
		{
			head=tail=n;
			return;
		}
	
		else
		{
                        p=head;
			while(p->next != NULL)
			{
				if((n->info > p->info) && (n->info <= p->next->info))
				{
					n->next=p->next;
					p->next=n;
					p->next->next->prev=n;
					n->prev=p;
                                        return;
				}
                                p=p->next;
                        }
                
			if(n->info>head->info)
			{
				head->prev=n;
				n->next=head;
				head=n;
			}
			else if(n->info>tail->info)
			{
				tail->next=n;
				n->prev=tail;
				tail=n;
			}
		}
        }
        
		
	void del(int pos)
	{
                Node *p = new Node();
		int count=0;
		p=head;
		
                if(head==NULL)
	        {
	        	cout<<"\nCan't delete the ele. Empty list\n"; 
		        return ;
	        }

	       	while(p!=NULL)
	        {
		        count++; 
		        p=p->next; 
	        }

	        if(pos<1 || pos>count) 
	        {
		        cout<<"\nPosition is invalid\n"; 
		        return ;
        	}
              
		else
                 {
                       if(pos==1)
		        {
			        if(head==tail)
			        {
				        delete head;
			        	head=tail-NULL;
			        }
			else 
			{
				p=head;		
				head=head->next;
				delete 	p;
				p=NULL;
			}
		}
		else if(pos==count)
		{
			p=tail;
			tail=tail->prev;
			delete p;
			tail->next=NULL;
		}
		else
		{
			p=head;
			for(int i=0;i<pos;i++)

			p=p->next;
			p->prev->next=p->next;
			p->next->prev=p->prev;
		}
	}
}
	void traverse()
	{
		Node *p=new Node();
		p=head;
		while(p!=NULL)
		{
			cout<< p->info;
			p=p->next;
		}
	}

};

int main()
{
	int ch,n,a,c;
	odll o;
	do
	{
		cout<<"1.Add an element\n";
		cout<<"2.Delete from position\n";
		cout<<"3.Display";
		cout<<"Choose one option";
		cin>>ch;
		switch(ch)
		{
			case 1:cout<<"Enter an element";
				cin>>n;
				o.add(n);
				break;
			case 2:cout<<"Delete from position";
				cin>>a;
				o.del(a);
				break;
			case 3:o.traverse();
		}
		cout<<"Do you want to continue";
		cin>>c;
	}while(c=='y'||c=='Y');
	
return 0;
}
				

					
