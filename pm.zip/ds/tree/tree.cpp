#include<iostream>
using namespace std;
class bstnode {
	public:
	int key;
	bstnode *left;
	bstnode *right;
	bstnode()
	{
		key=0;
		left=NULL;
		right=NULL;
	}
	bstnode(int val,bstnode *left1=0,bstnode *right1=0)
	{
		key=val;
		left=left1;
		right=right1;
	}
};

class bst 
{
	public:
	bstnode *root=0,*p=0,*temp;
	int s=0,d=0;
	void add(int val)
	{
		bstnode *node=new bstnode(val);
		if(root==NULL)
			root=node;
		else
		{
			temp=root;
			while(temp!=0)
			{
				p=temp;
				if(temp->key<val)
					temp=temp->right;
				else
					temp=temp->left;
			}
		if(p->key>val)
			p->left=node;
		else
			p->right=node;
		}
	}
	void deletemer(int val)
	{
		temp=p=root;
		while(temp!=0)
		{
			if(val==temp->key)
				break;
				p=temp;
			if(val>temp->key)
				temp=temp->right;
			else 
				temp=temp->left;
		}
		if(temp->right==0 && temp->left==0)
		{
			delete p;
			p=0;
		}	
		else if(temp->left==0 || temp->right == 0 )
		{
			if(p->key > temp->key)
			{
				if(temp->left==0)
				p->left=temp->right;
				else
				p->left=temp->left;
				delete temp;
				temp=0;
			}
			else 
			{
				if(temp->left==0)
				p->right=temp->right;
				else
				p->right=temp->left;
				delete temp;
				temp=0;
			}		

		}
		else
		{
			bstnode *next,*q=temp->left;
			while(q->right!=0)
				q=q->right;
			q->right=temp->right;
			if(p->key>q->key)
				p->left=q;
			else
				p->right=q;
			delete temp;
			temp=0;
		}	
	}
	void leaf(bstnode *root)
	{			
		if(root==0)
			return;
		else 
		{		
			leaf(root->left);
			leaf(root->right);
			if(root->right==0 && root->left ==0)
				s++;
			else
				d++;
		}
				
	}

};
int main() 
{
	bst obj;
	obj.add(97);
	obj.add(90);
	obj.add(105);
	obj.add(85);
	obj.add(80);
	obj.add(87);
	obj.add(95);
	obj.add(93);
	obj.add(103);
	obj.add(105);
	obj.add(107);
	obj.add(110);
	obj.leaf(obj.root);
	//obj.deletemer(110);
	cout<<"No.of non leaf node"<<obj.s<<"\nNo.of leaf nodes "<<obj.d<< " ";
	return 0;
}		
