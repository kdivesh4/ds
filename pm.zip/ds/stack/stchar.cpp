#include<iostream>
#define MAX 50
using namespace std;

class stk
{
public:
	char s[MAX];
	char top ;	
	char el;
	stk()
	{
		top=-1;
	}	
	void push(char);
	void pop();
	void display();
	char topel();
	bool isEmpty();
	bool isFull();
};
	
	bool stk::isEmpty()
	{
		if(top=-1)
		return true;
		else
		return false;
	}

	bool stk::isFull()
	{
		if(top=MAX-1)
		return true;
		else
		return false;
	}


	void stk::push(char el)
	{
	
		if(top<(MAX-1))
		{
			top++;			
			s[top]=el;
		}
	}

	
	void stk::pop()
	{
		if(top!=-1)
		top--;
		else
		cout<<"Underflow";
	}

	void stk::display()
	{
		if(top<0)
		{
			cout <<" Stack is now empty";
			return;
		}
		for(int i=top;i>=0;i--)
		cout <<s[i] <<" ";
	}

	char stk::topel()
	{
		if(top!=-1)
		{	
			return (s[top]);
		}
		else 
		{
			return 2;
		}
	}

int main()
{
	int ch;
	char c;
	char t;
	bool f,e;
	stk st;
	while(1)
        {
		cout<<"\n---Stack of Characters---\n1.push()  \n2.pop()  \n3.isFull()  \n4.isEmpty() \n5.display() \n6.topel() \nEnter your choice :- ";
                cin>>ch;
                switch(ch)
		{
			case 1:	cout<<"Enter the element to stack :";
                        	cin>>c;
                        	st.push(c);
                        	break;
			case 2:	st.pop();  
				break;
                	case 3:	f=st.isFull();
				if(f=true)
				cout<<"Stack is full";
				else if(f=false)
				cout<<"Stack is not full";
				break;
                	case 4:	e=st.isEmpty();
				if(e=true)
				cout<<"Stack is empty";
				else if(e=false)
				cout<<"Stack is not empty";
				break;
                	case 5: cout<<"Elements in the stack";
				st.display();
				break;
			case 6:	t=st.topel();
				if(t!=2)
				cout<<"Top element in the stack : "<<t<<endl;
				else if(t==2)
				cout<<"Invalid number"<<endl;
				break;
				
		}
         }
return 0;
}
