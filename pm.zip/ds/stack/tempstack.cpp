#include<iostream>
#include <climits>
using namespace std;
#define MAX 10
#define invalid_no CHAR_MAX
template <class T>
class stack {
	int top;	
	public:
	T a;
	T s[MAX];
	stack();
	void push(T el);
	void pop();
	T topel();
	void clear();
	bool isEmpty();
	bool isFull();
	};
template <class T>
stack <T>:: stack() {
	top=-1;
	}
template <class T>
void stack <T>:: push(T el) {
	++top;
	if(top<MAX)
	s[top]=el;
	else
		cout<<"overflow\n "; 
	}
template <class T>
void stack<T>  :: pop() {
	if(top!=-1)
	--top;
	else 	
	cout<<"underflow\n";		
	}
template <class T>
T stack<T> :: topel() {
	if(top!=-1)
		return s[top];
	else
		return invalid_no;
	}
template <class T>
void stack <T>:: clear() {
	top=-1;
	}
template <class T>
bool stack <T>:: isEmpty() {
	if(top==-1)
		return true;
	else
		return false;
	}
template <class T>
bool stack <T>:: isFull() {
	if(top==(MAX-1))
		return true;
	else
		return false;
		}
int main() {
	int ch,choice=0,st;
	stack <int>stk1;
	stack <char>stk2;
	cout<<"1.Stack(integer) 1st\n2.Stack(char) 2nd\n";
	cin>>st;
	if(st==1 || st==2) {
	cout<<"1. push\n2. pop\n3. IsEmpty\n4. Is Full\n5. Clear\n6. Topel\n";
	while(choice==0) {	
	cout<<"enter the choice\n ";	
	cin>>ch;	
	switch(ch) {
	case 1:{
		cout<<"enter element to push\n";
		if(st==1) {
		cin>>stk1.a;
		stk1.push(stk1.a);
		for(int i=0;i<MAX;i++)
			cout<<stk1.s[i]<<" ";	
			}
		else if(st==2) {
		cin>>stk2.a;
		stk2.push(stk2.a);
		for(int i=0;i<MAX;i++)
			cout<<stk2.s[i]<<" ";	
			}
		}
	break;
	case 2: {
		if(st==1)
		stk1.pop();
		else if(st==2)
		stk2.pop();
		}
	break;
	case 3: {
		if(st==1)
		cout<<stk1.isEmpty()<<"\n";
		else if(st==2)				
		cout<<stk2.isEmpty()<<"\n";
		}
	break;
	case 4: {
		if(st==1)
		cout<<stk1.isFull()<<"\n";
		else if(st==2)				
		cout<<stk2.isFull()<<"\n";
		}
	break;
	case 5: { 
		if (st==1)
		stk1.clear();
		else if(st==2)
		stk2.clear();		
		}
	break;
	case 6: {
		if(st==1)
		cout<<stk1.topel()<<"\n";
		else if(st==2)				
		cout<<stk2.topel()<<"\n";
		}
	default: cout<<"pls enter valid option\n";
	}
	}
	}
	else
	cout<<"enter a valid option\n";
	
	return 0;
}

