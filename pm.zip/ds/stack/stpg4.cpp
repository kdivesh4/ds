#include<iostream>
#define MAX 50
using namespace std;
template <class A>
class stk
{
public:
	A s[MAX];
	int top;	
	int el;
	stk();
	bool isEmpty();
	bool isFull();
	void pop();
	void display();
	void push(T el);
	A topel();
};

template <class A>
stk <T> :: stk()
{ 
	stk()
	{
		top=-1;
	}
}
	
template <class A>
bool stk <A> :: isEmpty()
	{
		if(top=-1)
		return true;
		else
		return false;
	}
template <class A>
bool stk <A> :: isFull()
	{
		if(top=MAX-1)
		return true;
		else
		return false;
	}

template <class A>
void stk <A> :: push(T el)
	{
	
		if(top<(MAX-1))
		{
			top++;			
			s[top]=el;
		}
	}

template <class A>
void stk <A> :: pop()	
	{
		if(top!=-1)
		top--;
		else
		cout<<"Underflow";
	}

template <class A>
void stk <T> :: display()
	{
		if(top<0)
		{
			cout <<" Stack is now empty";
			return;
		}
		for(int i=top;i>=0;i--)
		cout <<s[i] <<" ";
	}

template <class A>
A int stk <A> :: topel()
	{
		if(top!=-1)
		return (s[top]);
		else 
		cout<<"Invalid Number";
	}


int main()
{
	int ch,c,t;
	bool f,e;
	stk st1;
	stk st2;
	while(1)
        {
		cout <<"\n---Stack of Integers---\n1.push()  \n2.pop()  \n3.isFull()  \n4.isEmpty() \n5.display() \n6.topel() \nEnter your choice :- ";
                cin >> ch;
                switch(ch)
		{
			case 1:	cout <<"Enter the element to stack :";
                        	cin >> c;
                        	st.push(c);
                        	break;
			case 2:	st.pop();  
				break;
                	case 3:	f=st.isFull();
				if(f=true)
				cout<<"Stack is full";
				else
				cout<<"Stack is not full";
				break;
                	case 4:	e=st.isEmpty();
				if(e=true)
				cout<<"Stack is empty";
				else
				cout<<"Stack is not empty";
				break;
                	case 5: st.display();
				break;
			case 6: t=st.topel();
				cout<<"Top element in the stack"<<t;
				break;
		}
         }
return 0;
}
