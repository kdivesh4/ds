#include <iostream>

using namespace std;
#define SIZE 100
template<class X>
class Stack{

    int top;
    X stck[SIZE];
    public:
    Stack(){top=-1;}

    void push(X);
    void pop();
    X topel();
    void Clear(){top=-1;}
    bool isEmpty(){if(top==-1)return true; else return false;}

    bool isFull(){if(top==SIZE-1)return true; else return false;}

    void display(){cout<<"\n    Stack is::";
            cout<<"\n\nTop-->  ";
          for(int i=top;i>=0;i--)cout<<stck[i]<<endl<<"\t";
     }

};

template<class X>
void Stack<X>::push(X ele){

  if(!isFull())
   stck[++top]=ele;
   else
    cout<<"Stack overflow\n";
}

template<class X>
void Stack<X>::pop(){

   if(!isEmpty()){
    top--;
   }
   else
        cout<<"Stack underflow\n";
}

template<class X>
X Stack<X>::topel(){

    if(!isEmpty())
        return stck[top];
    else {
       return stck[0];
       }
    }

int main(){
    char op,op1,ch,ech;
    int ele,num;
  Stack<int> intStack1;
  Stack<char> charStack1;
  do{
    cout<<"\n\n\t  MENU::";
    cout<<"\na) Run operations on Stack objects.";
    cout<<"\nb) Change infix expression into postfix expression.";
    cout<<"\nc) Add big integers using stacks.";
    cout<<"\nd) Exit.";
    cout<<"\n\nChoose an option: ";
    cin>>op;

    switch(op){

     case 'a': do{ cout<<"1) Push element(int).\n2) Push element(char).\n3) Pop element(int).\n4) Pop element(int).\n5) Display Top element(int).\n6) Display Top element(char).\n7) clear Stack(int).\n8) clear Stack(char).\n9) Display stack (int).\n10)Display Stack(char)";
               cout<<"\n\nChoose option: ";
               cin>>op1;
               switch(op1){
                 case '1':cout<<"\nEnter element: ";
                 cin>>ele;
                intStack1.push(ele);
                intStack1.display();
                  break;

                  case '2': cout<<"\nEnter element: ";
                            cin>>ech;
                            charStack1.push(ech);
                            charStack1.display();
                            break;

                  case '3': intStack1.pop();
                            cout<<"\nElement has been removed.";
                             intStack1.display();
                              break;

                  case '4': charStack1.pop();
                            cout<<"\nElement has been removed.";
                             charStack1.display();
                              break;

                  case '5': if(intStack1.isEmpty())
                                cout<<"\nStack is empty.";
                            else cout<<"\nTop element is: "<<intStack1.topel();
                            break;


                  case '6': if(charStack1.isEmpty())
                                cout<<"\nStack is empty.";
                            else cout<<"\nTop element is: "<<charStack1.topel();
                            break;

                  case '7': intStack1.Clear();
                            cout<<"\nInt Stack has been cleared successfully.";
                            break;

                  case '8': charStack1.Clear();
                            cout<<"\nChar Stack has been cleared successfully.";
                            break;

                  case '9':intStack1.display();
                            break;
                  case '10': charStack1.display();
                              break;
                  default: cout<<"\nWrong input! ";

               }
               cout<<"\nPress y to go back to menu: ";
               cin>>ch;
             }while(ch=='y'||ch=='Y');
                break;

       case 'b': break;

       case 'c': break;

       case 'd':return 0;
    }
    cout<<"\n\nTo go to the main menu: Press Y.";
    cin>>ch;
  }while(ch=='y'||ch=='Y');

}
