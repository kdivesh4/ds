#include <iostream>
#include<stdlib.h>
using namespace std;
#define MAX 10
class queue {
	int q[MAX];
	int first;
	int last;
	public:
	queue() {
		first=-1;
		last=-1;
		}			
	void clear() { 
		first=-1;
		last=-1;		
		}
	void enqueue(int el) { 
	if(!isFull()) {
		if(last==-1 || last==MAX-1) {
			q[0]=el;
			last=0;
			if(first==-1)
				first=0;
					}
		else  {
			++last;			
			q[last]=el;			
			}	
				}
	else if(isFull())
 		{
		cout<<"Overflow\n";
		exit(0);
		}		
	}
	int dequeue() {
		if(!isEmpty()) {
		int temp;
		if(first==MAX-1) {
			temp=first;			
			first=0;
			return q[temp];
			}	
		else if(first==last) {
			temp=first;			
			first=-1;
			last=-1;
			return(q[temp]);
			} 
		else
		return ( q[first++]);
			}
		else {
			cout<<"underflow\n";
			exit(0);
			}		
		}
	bool isFull() {
		if(first==last+1 || (first==0 && last==MAX-1))
			return true;
		else
			return false;			
			 }
	bool isEmpty() {
		if(first==-1 && last == -1)
			return true;
		else
			return false;				
		 }
	void view() {
		cout<<"first="<<first<<endl;
		cout<<"last="<<last<<endl;
	}};
int main() {
	int ch,choice=0,st;
	queue q1;
	queue q2;
	cout<<"1.Queue 1st\n2.Queue 2nd\n";
	cin>>st;
	if(st==1 || st==2) {
	cout<<"1. Enqueue\n2. Dequeue\n3. IsEmpty\n4. Is Full\n5. Clear\n6. Exit\n";
	while(choice==0) {	
	cout<<"enter the choice\n ";	
	cin>>ch;	
	switch(ch) {
	case 1:{int a;
		cout<<"enter element to push\n";
		cin>>a;
		if(st==1)
		q1.enqueue(a);
		else if(st==2)
		q2.enqueue(a);
		}
	break;
	case 2: {
		if(st==1)
		cout<<"Element dequed "<<q1.dequeue()<<endl;
		else if(st==2)
		cout<<"Element dequed "<<q2.dequeue()<<endl;
		}
	break;
	case 3: {
		if(st==1)
		cout<<q1.isEmpty()<<"\n";
		else if(st==2)				
		cout<<q2.isEmpty()<<"\n";
		}
	break;
	case 4: {
		if(st==1)
		cout<<q1.isFull()<<"\n";
		else if(st==2)				
		cout<<q2.isFull()<<"\n";
		}
	break;
	case 5: { 
		if (st==1)
		q1.clear();
		else if(st==2)
		q1.clear();		
		}
	break;
	case 6: exit(0);
	break;	
	case 7: q1.view();
	break;
	default: cout<<"pls enter valid option\n";
	}
	}
	}
	else
	cout<<"enter a valid option\n";
	return 0;
	}
