#include<iostream>
using namespace std;
class Node
{
	public:
	int info;
	Node *next;
	Node()
	{
		info=0;
		next=NULL;
	}
};
class SLList 
{
	public:
	Node *head;
	Node *tail;
	SLList()
	{
		head=NULL;
		tail=NULL;
	}
	void addtohead(int val)
	{
		Node *n=new Node();
		if(head==NULL)
		{
			n->info=val;
			head=n;
			tail=n;
		}
		else
		{
			n->info=val;
			n->next=head;
			head=n;
		}
	}
	void addtotail(int val)
	{
		Node *n=new Node();
		if(tail==NULL)
		{
			head=n;
			tail=n;
			tail->info=val;
		}
		else
		{
			tail->next=n;
			tail=n;
			tail->info=val;
		}
	}
	void display()
	{
		Node *p=new Node();
		p=head;
		while(p!=NULL)
		{
			cout<<"\n"<< p->info;
			p=p->next;
		}
	}
	bool search(int x)
	{
		Node *p=new Node();
		p=head;
		while(p!=NULL)
		{
			if(p->info==x)
				return true;
			p=p->next;
		}
		return false;
	}
	void deletefromhead()
	{
		Node *p=new Node();
		if(head==NULL)
			cout<<"\n No Nodes";
		else if((head!=NULL)&&(head==tail))
		{
			p=head;
			cout<<"\n Deleted Node = "<<p->info;
			head=head->next;
			delete p;
			p=NULL;
			tail=NULL;
		}
		else
		{
			p=head;
			cout<<"\n Deleted Node = "<<p->info;
                        head=head->next;
                        delete p;
		}
	}
};
int main()
{
	SLList s1;
	int choice,val;
	char ch;
	bool ans;
	do
	{
		cout<<"\n Menu";
		cout<<"\n 1. Add to Head";
		cout<<"\n 2. Add to Tail";
		cout<<"\n 3. Display list";
		cout<<"\n 4. Search";
		cout<<"\n 5. Delete";
		cout<<"\n Enter choice: ";
		cin>>choice;
		switch(choice)
		{
			case 1:  cout<<"\n\n Enter the value = ";
				 cin>>val;
				 s1.addtohead(val);
				 break;

			case  2: cout<<"\n\n Enter the value = ";
                                 cin>>val;
                                 s1.addtotail(val);
                                 break;

			case 3:  s1.display();
				 break;

			case 4:  cout<<"\n\n Enter element to search= ";
				 cin>>val;
				 ans=s1.search(val);
				if(ans)
					cout<<"\n Element found!";
				else
					cout<<"\n Element not found!";
				 break;
		
			case 5:  s1.deletefromhead();
				 break;
			
			default: cout<<"\n\n Invalid choice!";
		}
		cout<<"\n Doyou want to continue?(Y/N)";
		cin>>ch;
	}while(ch=='Y'||ch=='y');

	return 0;
}
