#include<iostream>
using namespace std;

class Node {
  public:
char info;
Node *next,*prev;

Node(){
info='a';
next=NULL;
prev=NULL;
}


};

class ODLL{

       public:
   Node *head=NULL,*tail=NULL,*p;
	void add_an_ele(char val){
	Node* newNode= new Node();
	newNode->info=val;
	if(head==NULL) {
	head=tail=newNode;
	return;
	}	
	else{
	p=head;
	while(p->next!=NULL){
		if(newNode->info > p->info && newNode->info<= p->next->info){
			newNode->next=p->next;
			p->next=newNode;
			p->next->next->prev=newNode;
			newNode->prev=p;
			return;
		}
	   p=p->next;
	}
	if(newNode->info <= head->info){
		head->prev=newNode;
		newNode->next=head;
		head=newNode;
		return;
	}
	else if(newNode->info > tail->info){
		tail->next=newNode;
		newNode->prev=tail;
		tail=newNode;
		return;
	}

     }
    	
	
 }


void del_ele(int pos)
{
	if(head==NULL)
	{
		cout<<"\nCan't delete the ele. Empty list\n"; 
		return ;
	}

	p=head;
	int count=0;
	while(p!=NULL)
	{
		count++; 
		p=p->next; 
	}

	if(pos<1 || pos>count) 
	{
		cout<<"\nPosition is invalid\n"; 
		return;
	}
	
	else
	{
		if(pos==1)
		{
	  		if(head==tail)
			{ 
				delete head;  
				head=tail=NULL; 
			}
  			else
			{
     				p=head;
     				head=head->next;
     				delete p;
     				head->prev=NULL;
  			}
		}

		else if(pos==count)
		{
			p=tail;
			tail=tail->prev;
			delete p;
			tail->next=NULL;
		}
	
		else
		{
			p=head;
			for(int i=0;i<pos-1;i++) 
			p=p->next;	
			p->prev->next=p->next;   
			p->next->prev=p->prev;
			delete p;
		}
	}

}

void traverse(){
if(head!=NULL){
p=head;
cout<<"\nList-> ";
while(p!=NULL){cout<<p->info<<" ";  p=p->next; }
cout<<endl;
}
else cout<<"\nEmpty List\n";
}

};


int main(){
ODLL list;
list.add_an_ele('b');
list.add_an_ele('a');
list.add_an_ele('g');
list.add_an_ele('i');
list.traverse();
list.del_ele(1);
list.traverse();
list.add_an_ele('e');
list.traverse();
list.del_ele(2);
list.traverse();
list.del_ele(3);
list.del_ele(2);
list.traverse();
list.del_ele(1);
list.traverse();
return 0;

}
