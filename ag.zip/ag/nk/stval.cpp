#include<iostream>
#define MAX 50
using namespace std;

class stk
{
public:
	char s[MAX];
	char top ;	
	char el;
	stk()
	{
		top=-1;
	}	
	void push(char);
	void pop(char);
	void display();
	char topel();
	int chk(char el);
};
	
	

	void stk::push(char el)
	{
	
		if(top<(MAX-1))
		{
			top++;			
			s[top]=el;
		}
	}

	
	void stk::pop(char el)
	{
		if(top!=-1)
		top--;
		else
		cout<<"Underflow";
	}

	void stk::display()
	{
		if(top<0)
		{
			cout <<" Stack is now empty";
			return;
		}
		for(int i=top;i>=0;i--)
		cout <<s[i] <<" ";
	}

	char stk::topel()
	{
		if(top!=-1)
		{	
			return (s[top]);
		}
		else 
		{
			return 2;
		}
	}

	int stk::chk(char el)
	{
		if(top<(MAX-1))
		{
			if(el=='{'|| el=='[' || el=='(')
			{ 
				return 3;
			}
			else if(el=='}' || el==']' || el==')')
			{
				return 4;
			}
		}
	}
			

int main()
{
	int c;
	char br,t,q;
	
	stk st;
	
	while(1)
	{ 
		cout<<"\n1.Enter expression to check its validity: \n2.dispaly() \n3.topel() \nEnter your choice :- ";
		cin>>c;
		switch(c)
		{
			case 1:	cout<<"Enter expression containing only "<<" { "<<" [ "<<" ( "<<" to check validity of brackets :-"<<endl;
				cin>>br;
				q=st.chk(br);			
				if(q==3)
				st.push(br);	
				else if(q==4)
				{
				t=st.topel();
				st.pop(t);
				}				
				break;
			case 2:	cout<<"Elements in the stack : ";
				st.display();
				break;
			case 3:	t=st.topel();
				if(t!=2)
				cout<<"Top element in the stack : "<<t<<endl;
				else if(t==2)
				cout<<"Invalid number"<<endl;
				break;
				
		}
	
	}
return 0;
}


	
