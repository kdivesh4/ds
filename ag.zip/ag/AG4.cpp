#include<stdlib.h>
#include<string>
#include<iostream>
using namespace std;
#define MAX 50
class Stack
  {
	char arr[MAX];
	int top;
     public:
	Stack()
	  {
		top=-1;
	   }
    
	void push(char el)
	  {
		if(top+1<MAX)
		  {
		     top++;
		     arr[top]=el;
		   }
	   }
	void pop()
	  {
		if(top!=-1)
		  top--;
	   }
	void clear()
	  {
		top=-1;
	   }
	bool isEmpty()
	  {
		if(top==-1)
		  return true;
		else
		  return false;
	   }
	char topel()
	  {
		if(top!=-1)
		  return arr[top];
		else
		  return 'a';
	   }
	bool isFull()
	  {
		if(top==MAX-1)
		  return true;
		else
		  return false;
	   }
};
  int main()
   {
	Stack S;
	string A;
	int i;
	cout<<"Program to check the validity of an expression\n Enter the expression whose validity is to be checked\n";
	cin>>A;
	for(i=0;i<A.length();i++)
	   { 
		if(A[i]=='{'||A[i]=='('||A[i]=='[')
		   S.push(A[i]);
		else if(A[i]=='}'&& S.topel()=='{')
		   S.pop();
		else if(A[i]==')'&& S.topel()=='(')
		   S.pop();
		else if(A[i]==']'&& S.topel()=='[')
		   S.pop();
		else if(A[i]=='}'&& S.topel()!='{')
		   {
			cout<<"Invalid Expression\n";
			exit(0);
		    }
		else if(A[i]==')'&& S.topel()!='(')
		   {
			cout<<"Invalid Expression\n";
			exit(0);
		    }
		else if(A[i]==']'&& S.topel()!='[')
		   {
			cout<<"Invalid Expression\n";
			exit(0);
		    }
	    }
	if(S.isEmpty())
	  cout<<"Expression is valid\n";
	else
	   cout<<"Expression is not valid\n";
   }
		
		
	    
     else if(((str[i]=='+')&&(st1.topel()=='-'))||((str[i]=='-')&&(st1.topel()=='+'))||((str[i]=='*')&&(st1.topel()=='/'))||((str[i]=='/')&&(st1.topel()=='*')))

