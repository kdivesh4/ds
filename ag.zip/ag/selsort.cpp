#include<iostream>
using namespace std;
int main()
{

	int i,j,temp,n,ar[10];
	cout<<"Enter nos";
	cin>>n;
	cout<<"Enter"<< n <<" no.: \n";
	for(i=0;i<n;i++)
	{
	 cin>>ar[i];
	}

	for(i=0;i<n;i++)
	{
	 for(j=i+1;j<n;j++)
	 {
	  if(ar[i]>ar[j])
		{
		  temp=ar[i];
		  ar[i]=ar[j];
		  ar[j]=temp;
 	
		}
	 } 
	}
	for(i=0;i<n;i++)
	  {
	   cout<<ar[i] ;
	  }	
	
 }
