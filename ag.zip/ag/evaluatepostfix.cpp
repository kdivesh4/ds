#include<iostream>

using namespace std;
#define SIZE 100

class Stack{

    int top;
    int stck[SIZE];
    public:
    Stack(){top=-1;}

    void push(int);
    void pop();
    int topel();
    void Clear(){top=-1;}
    bool isEmpty(){if(top==-1)return true; else return false;}

    bool isFull(){if(top==SIZE-1)return true; else return false;}

    void display(){cout<<"\n    Stack is::";
            cout<<"\n\nTop-->  ";
          for(int i=top;i>=0;i--)cout<<stck[i]<<endl<<"\t";
     }

};

void Stack::push(int ele){

  if(!isFull())
   stck[++top]=ele;
   else
    cout<<"Stack overflow\n";
}

void Stack::pop(){

   if(!isEmpty()){
    top--;
   }
   else
        cout<<"Stack underflow\n";
}

int Stack::topel(){

    if(!isEmpty())
        return stck[top];
    else {
       return stck[0];
       }
}

int main()
{
	string str;
	int i,a,b;
	Stack st;
	char ch;
	do{
	cout<<"Enter the expression to be evaluated: \n";
	cin>>str;
	for(i=0;i<str.length();i++)
	{
		switch(str[i])
		{
			case'+': a=st.topel();
				st.pop();
				 b=st.topel();
				 st.pop();
				 st.push(a+b);
				 break;
			case'-': a=st.topel();
				 st.pop();
				 b=st.topel();
				 st.pop();
				 st.push(b-a);
				 break;
			case'*': a=st.topel();
				 st.pop();
				 b=st.topel();
				 st.pop();
				 st.push(a*b);
				 break;
			case'/': a=st.topel();
				 st.pop();
				 b=st.topel();
				 st.pop();
				 st.push(b/a);
				 break;
			default: if(str[i]==' ')
				  break;
				 else
				  {
				   
				   st.push((int)str[i]-48);
				  }
		}
	}

	cout<<"\nThe result is "<<st.topel();
	cout<<"\nTo try again press 'Y': ";
	cin>>ch;
	}while(ch=='y'||ch=='Y');
}
