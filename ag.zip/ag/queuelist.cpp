#include<iostream>
#include<cstdlib>
using namespace std;

class IntSLLNode{

 public:
  int info;
  IntSLLNode *next;

IntSLLNode(){
info=0;
next=NULL;
}

IntSLLNode(int val,IntSLLNode* ptr){
info=val;
next=ptr;
}

};


class IntSLL{


IntSLLNode* head=NULL;
IntSLLNode* tail=NULL;

public:

void addtotail(){
int info;
cout<<"\nEnter the info: ";
cin>>info;
IntSLLNode *node = new IntSLLNode(info,NULL);
if(tail==NULL)
head=tail=node;
else{
tail->next=node;
tail=node;
}
cout<<"\nElement added.";
traverse();
}

void delfromhead(){
IntSLLNode* temp=head;
if(head==NULL)cout<<"\nCannot delete, Queue is Empty.";
else if(head==tail){
head=tail=NULL;
delete temp;
cout<<"\nElement deleted.\n";
traverse();
}
else if(head!=NULL){
head=head->next;
delete temp;
cout<<"\nElement deleted.\n";
traverse();
}
}

int search(int var){
IntSLLNode* p=head;
int count1=0;
while(p!=NULL){
       count1++;
if(p->info==var)return count1;
p=p->next;
}
return -1;
}

void traverse(){
IntSLLNode* p=head;
cout<<"\nQueue-> ";
if(p!=NULL){
	while(p!=NULL){
	cout<<p->info<<"  ";
	p=p->next;
	}
}
else cout<<"Empty";
}


};

int main(){
IntSLL list;
char ch;
int ele,pos;
cout<<"\nQUEUE Using Linked List.";
do{
cout<<"\n\nMENU::\n1)Add Element.\n2)Delete Element.\n";
cout<<"3)Traverse.\n4)search element.\n5)Exit.\n";
cout<<"\nEnter your choice: ";
cin>>ch;
switch(ch){
case '1':list.addtotail();
 break;
case '2':list.delfromhead();
 break;
case '3':list.traverse();
 break;
case '4':cout<<"\nEnter ele to search: ";
          cin>>ele;
         pos=list.search(ele);
         if(pos!=-1)cout<<"\nElement found at index: "<<pos-1<<endl;
         else cout<<"\nElement not found.\n";
 break;
case '5':exit(0);
default: cout<<"\nWrong choice!!";

}
}while(true);
return 0;
}
