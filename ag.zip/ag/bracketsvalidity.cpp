#include <iostream>
#include<string>
using namespace std;
#define SIZE 100

class Stack{


    int top;
    char stck[SIZE];

    public:
    Stack(){top=-1;}

    void push(char);
    void pop();
    char topel();
    void Clear(){top=-1;}
    bool isEmpty(){if(top==-1)return true; else return false;}

    bool isFull(){if(top==SIZE-1)return true; else return false;}

    void display(){cout<<"\n    Stack is::";
            cout<<"\n\nTop-->  ";
          for(int i=top;i>=0;i--)cout<<stck[i]<<endl<<"\t";
     }
     int gettopindex(){return top;}

};


void Stack::push(char ele){

  if(!isFull())
   stck[++top]=ele;
   else
    cout<<"Stack overflow\n";
}


void Stack::pop(){

   if(!isEmpty()){
    top--;
   }
   else
        cout<<"Stack underflow\n";
}


char Stack::topel(){

    if(!isEmpty())
        return stck[top];
    else {
       return 'a';
       }
    }

int main(){

	Stack st;
	string str;
	char ch;
	int i;
	do{
	cout<<"\nEnter the Expression: ";
	cin>>str;
	for(i=0;i<str.length();i++)
	   {
		if(str[i]=='{'||str[i]=='('||str[i]=='[')
		   st.push(str[i]);
		else if(str[i]=='}'&& st.topel()=='{')
		   st.pop();
		else if(str[i]==')'&& st.topel()=='(')
		   st.pop();
		else if(str[i]==']'&& st.topel()=='[')
		   st.pop();
		else if(str[i]=='}'&& st.topel()!='{')
		   {
			cout<<"Expression is INVALID\n";
			exit(0);
		    }
		else if(str[i]==')'&& st.topel()!='(')
		   {
			cout<<"Expression is INVALID\n";
			exit(0);
		    }
		else if(str[i]==']'&& st.topel()!='[')
		   {
			cout<<"Expression is INVALID\n";
			exit(0);
		    }
	    }
	if(st.isEmpty())
	  cout<<"Expression is VALID\n";
	else
	   cout<<"Expression is INVALID\n";

	   cout<<"\nTo try again press 'Y': ";
	   cin>>ch;
    }while(ch=='y'||ch=='Y');
	 return 0;
}


