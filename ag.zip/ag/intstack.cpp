#include<iostream>

using namespace std;
#define SIZE 100

class Stack{

    int top;
    int stck[SIZE];
    public:
    Stack(){top=-1;}

    void push(int);
    void pop();
    int topel();
    void Clear(){top=-1;}
    bool isEmpty(){if(top==-1)return true; else return false;}

    bool isFull(){if(top==SIZE-1)return true; else return false;}

    void display(){cout<<"\n    Stack is::";
            cout<<"\n\nTop-->  ";
          for(int i=top;i>=0;i--)cout<<stck[i]<<endl<<"\t";
     }

};

void Stack::push(int ele){

  if(!isFull())
   stck[++top]=ele;
   else
    cout<<"Stack overflow\n";
}

void Stack::pop(){

   if(!isEmpty()){
    top--;
   }
   else
        cout<<"Stack underflow\n";
}

int Stack::topel(){

    if(!isEmpty())
        return stck[top];
    else {
       return stck[0];
       }
    }


int main(){

Stack intStack1;
char op1,ch;
int ele;
 do{
     cout<<"\n\tMENU::";
    cout<<"\n1) Push element.\n2) Pop element.\n3) Display Top element.\n4) clear Stack.\n5)Display Stack";
            cout<<"\n\nChoose option: ";
               cin>>op1;
               switch(op1){
                  case '1':cout<<"\nEnter element: ";
                          cin>>ele;
                          intStack1.push(ele);
                          intStack1.display();
                           break;


                  case '2': intStack1.pop();
                            cout<<"\nElement has been removed.";
                             intStack1.display();
                              break;

                  case '3': if(intStack1.isEmpty())
                                cout<<"\nStack is empty.";
                            else cout<<"\nTop element is: "<<intStack1.topel();
                            break;

                  case '4': intStack1.Clear();
                            cout<<"\nInt Stack has been cleared successfully.\n";
                            break;

                  case '5':intStack1.display();
                            break;

                  default: cout<<"\nWrong input! ";

               }
               cout<<"\nPress y to go back to menu: ";
               cin>>ch;
             }while(ch=='y'||ch=='Y');

}
