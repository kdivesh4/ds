#include<iostream>
using namespace std;
class Node
{
	public:
	int info;
	Node *next;
	Node()
	{
		info=0;
		next=NULL;
	}
};
class OLList
{
	public:
	Node *head;
	Node *tail;
	OLList()
	{
		head=NULL;
		tail=NULL;
	}
	void add(int val)
	{
		Node *n=new Node();
		Node *p=new Node();
		p=head;
		if(head==NULL)
		{
			n->info=val;
			head=n;
			tail=n;
		}
		else if((head==tail)&&(head!=NULL)) 
		{
			if(p->info>val)
			{
				n->info=val;
				n->next=head;
				head=n;
			}
			else
			{
				n->info=val;
				tail->next=n;
				tail=n;
			}

		}
		else if(tail->info<val)
		{
                      n->info=val;
                      tail->next=n;
                      tail=n;
                }

		else
		{
			 if(head->info>val)
                        {
                                n->info=val;
                                n->next=head;
                                head=n;
                        }

			else
			{
				while(p->info<val)
				{
					if(p->next->info>=val)
						break;
					p=p->next;
				}
				n->info=val;
				n->next=p->next;
				p->next=n;
			}
		}
	}
	void Delete(int val)
	{
		int flag=0;
		Node *p=new Node();
		Node *q=new Node();
		p=head;
		if(head==NULL)
			cout<<"\n \n No elements\n ";
		else if(head==tail)
		{
			delete head;
			head=NULL;
			tail=NULL;
		}
	        if(head->info==val)
		{
			head=head->next;
			delete p;
			p=NULL;
		}
		else
		{
			while(p!=NULL)
			{
				if(p->next->info==val)
				{      flag=1;
					break;
				}
				p=p->next;
			}
			if(flag==1)
			{
				q=p->next;
				p->next=q->next;
				delete q;
			}
		}
	}
	void display()
	{
		Node *p=new Node();
		p=head;
		while(p!=NULL)
		{
			cout<<"\n"<<p->info;
			p=p->next;
		}
	}
};

int main()
{
	int val,choice;
	char ch;
	OLList l1;
	do
	{
	cout<<"\n\n Menu- ";
	cout<<"\n 1. Add";
	cout<<"\n 2. Delete";
	cout<<"\n 3. Display";
	cout<<"\n choice = ";
	cin>>choice;
	switch(choice)
	{
		case 1 :   cout<<"\n \n Enter the value = ";
			   cin>>val;
		           l1.add(val);
			   break;
		case 2:   cout<<"\n \n Enter the value you want to delete = ";
			  cin>>val;
			  l1.Delete(val);
			  break;

		case 3 :  l1.display();
			  break;

		default:  cout<<"\n\n Invalid Choice!";
	}
	cout<<"\n \n Do you wnat to continue?(Y/N)";
	cin>>ch;
	}while(ch=='Y'||ch=='y');
	return 0;
}
