#include<iostream>
using namespace std;
class Node
{
	public:
	int info;
	Node *next;
	Node *prev;
	Node()
	{
		info=0;
		next=NULL;
		prev=NULL;
	}
};
class DLList
{
	public:
	Node *head;
	Node *tail;
	DLList()
	{
		head=NULL;
		tail=NULL;
	}
	void addtohead(int val)
	{
		Node *n=new Node();
		if(head==NULL)
		{
			n->info=val;
			head=n;
			tail=n;
		}
		else
		{
			n->info=val;
			head->prev=n;	
			n->next=head;
			head=n;
		}
	}
	void addtotail(int val)
	{
		Node *n=new Node();
		if(tail==NULL)
		{
			n->info=val;
			head=n;
			tail=n;
		}
		else
		{
			n->info=val;
			n->prev=tail;
			tail->next=n;
			tail=n;
		}
	}
	void Rdisplay()
	{
		Node *p=new Node();
		p=tail;
		while(p!=NULL)
		{
			cout<<"\n"<<p->info;
			p=p->prev;
		}
	}
	void display()
	{
		Node *p=new Node();
                p=head;
                while(p!=NULL)
                {
                        cout<<"\n"<<p->info;
                        p=p->next;
                }
	}
	void deletefromhead()
	{
		Node *p=new Node();
		if(head==NULL)
			cout<<"\n  No Elements!";
		else if(head==tail)
		{
			p=head;
			head=head->next;
			delete p;
			p=NULL;
			tail=NULL;
		}
		else
		{
			p=head;
			head=head->next;
			head->prev=NULL;
			delete p;
			p=NULL;
		}
	}
	void deletefromtail()
	{
		Node *p=new Node();
		if(head==NULL)
			cout<<"\n No Elements!";
		else if(head==tail)
		{
			delete head;
			head=NULL;
			tail=NULL;
		}
		else
		{
			p=tail;
			tail=tail->prev;
			tail->next=NULL;
			delete p;
			p=NULL;
		}
	}
	void deletefrompos(int pos)
	{
		Node *p=new Node();
		p=head;
		for(int i=0;i<pos-1;i++)
			{
				p=p->next;
			}
		if(p==head)
		{
			 head=head->next;
			delete p;
                        p=NULL;
                }
		else if(p->next->next==NULL)
		{
			p=tail;
                        tail=tail->prev;
                        tail->next=NULL;
                        delete p;
                        p=NULL;
		}
		else
		{
			Node *q=new Node();
			q=p->next->next;
			p->next=q;
			delete q->prev;
			q->prev=p;
		}
	}
	void addafterpos(int val,int pos)
	{
		Node *n=new Node();
		Node *p=new Node();
		      p = head;
		for (int i = 0;i < pos - 1;i++)
		{
			p = p->next;
			if (p == NULL)
			{
				cout<<"There are less than ";
				cout<<pos<<" elements."<<endl;
				 return;
			}
		}
		n->info = val;

   	 	if (p->next == NULL)
	 	{
			p->next =n;
        		n->prev = p;
	 	}
		 else
		{
			n->next = p->next;
			n->next->prev =n;
			p->next = n;
			n->prev = p;
		}

	}
};
int main()
{

    int choice, val, pos;

    DLList dl;

    while (1)

    {

        cout<<endl<<"----------------------------"<<endl;

        cout<<endl<<"Operations on Doubly linked list"<<endl;

        cout<<endl<<"----------------------------"<<endl;         

        cout<<"1.Add to head"<<endl;

        cout<<"2.Add to tail"<<endl;

        cout<<"3.Add after position"<<endl;

        cout<<"4.Delete from head"<<endl;

        cout<<"5.Delete from tail"<<endl;

        cout<<"6.Delete from position"<<endl;

        cout<<"7.Reverse display"<<endl;

        cout<<"8.Display from head"<<endl;

	cout<<"9.Exit"<<endl;

        cout<<"Enter your choice : ";

        cin>>choice;

        switch ( choice )

        {

        case 1:

            cout<<"Enter the element: ";

            cin>>val;

            dl.addtohead(val);

            cout<<endl;

            break;

        case 2:

            cout<<"Enter the element: ";

            cin>>val;

            dl.addtotail(val);

            cout<<endl;

            break;

        case 3:

            cout<<"Enter the element: ";

            cin>>val;

            cout<<"Insert Element after postion: ";

            cin>>pos;

            dl.addafterpos(val,pos);

            cout<<endl;

            break;

        case 4: 
	    dl. deletefromhead();
	    break;
        case 5:

            dl.deletefromtail();
	   	break;

        case 6:
		cout<<"\n Enter position to delete: ";
		cin>>pos;
		dl.deletefrompos(pos);
		break;
	

        case 7:

            dl.Rdisplay();

            cout<<endl;

            break;

        case 8:

           	dl.display();
		break;
	case 9:
		return 0;

        default:

            cout<<"Wrong choice"<<endl;

        }

    }

    return 0;

} 
