#include <iostream>
#include<string>
using namespace std;
#define SIZE 100

class Stack{


    int top;
    char stck[SIZE];

    public:
    Stack(){top=-1;}

    void push(char);
    void pop();
    char topel();
    void Clear(){top=-1;}
    bool isEmpty(){if(top==-1)return true; else return false;}

    bool isFull(){if(top==SIZE-1)return true; else return false;}

    void display(){cout<<"\n    Stack is::";
            cout<<"\n\nTop-->  ";
          for(int i=top;i>=0;i--)cout<<stck[i]<<endl<<"\t";
     }
     int gettopindex(){return top;}

};


void Stack::push(char ele){

  if(!isFull())
   stck[++top]=ele;
   else
    cout<<"Stack overflow\n";
}


void Stack::pop(){

   if(!isEmpty()){
    top--;
   }
   else
        cout<<"Stack underflow\n";
}


char Stack::topel(){

    if(!isEmpty())
        return stck[top];
    else {
       return 'a';
       }
    }


int main(){

 Stack st1;
 Stack st2;
  string str, str2;
  char ch;
  int i;
  do{
        st1.Clear();
        st2.Clear();
        str2.clear();
    cout<<"\nWrite the infix expression: ";
    cin>>str;
    for(i=0;i<str.length();i++){
    if(str[i]=='+'||str[i]=='-'||str[i]=='*'||str[i]=='/'){
        if(st1.topel()==str[i]  ||  ( (st1.topel()=='*'||st1.topel()=='/') && (str[i]=='+'||str[i]=='-') ) ){
         st2.push(st1.topel());
         st1.pop();
         if(str[i]==st1.topel()||
            (str[i]=='+'&&st1.topel()=='-')||
            (str[i]=='-'&&st1.topel()=='+')||
            (str[i]=='*'&&st1.topel()=='/')||
            (str[i]=='/'&&st1.topel()=='*'))
            {
               st2.push(st1.topel());
               st1.pop();
            }
        st1.push(str[i]);
        }
      else if((str[i]=='+'&&st1.topel()=='-')||
              (str[i]=='-'&&st1.topel()=='+')||
              (str[i]=='*'&&st1.topel()=='/')||
              (str[i]=='/'&&st1.topel()=='*'))
            {
              st2.push(st1.topel());
              st1.pop();
              st1.push(str[i]);
            }

       else
            st1.push(str[i]);

    }

    else
        st2.push(str[i]);
    }

    while(!st1.isEmpty()){
        st2.push(st1.topel());
         st1.pop();
    }

      while(!st2.isEmpty()){            //reversing stack
        st1.push(st2.topel());
         st2.pop();
    }


       while(!st1.isEmpty()){          //getting expression into a string
        str2+=st1.topel();
         st1.pop();
    }

    cout<<"\nPostfix Expression is : "<<str2;

    cout<<"\nTo try again press 'Y': ";
     cin>>ch;

  }while(ch=='y'||ch=='Y');

  return 0;
}