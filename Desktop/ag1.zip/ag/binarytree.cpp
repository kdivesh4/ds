#include<iostream>
using namespace std;
lass Node
{
	public:
	int info;
	Node *left;
	Node *right;
	Node()
	{
		left=NULL;
		right=NULL;
		info=0;
	}
};
class BSTree
{
	public:
	Node *root;
	BSTree()
	{
		root=NULL;
	}
	void insert(int val)
	{
		Node *n=new Node();
		n->info=val;
		Node *parent;
		if(root==NULL)
		{
			root=n;
		}
		else
		{
			Node *p;
			p=root;
			while(p!=NULL)
			{
				if(val<p->info)
				{
					if(p->left==NULL)
						parent=p;
					p=p->left;
				}
				else if(val>p->info)
				{
					if(p->right==NULL)
						parent=p;
					p=p->right;
				}
			}
		}
		if(parent->info>val)
			parent->left=n;
		else if(val>parent->info)
			parent->right=n;
	}
	void preorder(Node *p)
	{
		if(root==NULL)
		{
			cout<<"\n Tree is empty";
			return;
		}
		if(p!=NULL)
		{
			cout<<" "<<p->info;
			preorder(p->left);
			preorder(p->right);
		}
	}
	
	void postorder(Node *p)
	{
		if(root==NULL)
		{
			cout<<"\n Tree is empty";
			return;
		}
		if(p!=NULL)
		{
			postorder(p->left);
			postorder(p->right);
			cout<<" "<<p->info;
		}
	}
	
	void inorder(Node *p)
	{
		if(root==NULL)
		{
			cout<<"\n Tree is empty";
			return;
		}
		if(p!=NULL)
		{
			inorder(p->left);
			cout<<" "<<p->info;
			inorder(p->right);
		}
	}

	
};
int main()
{
	BSTree t1;
	int value,ch;
	do{
	cout<<"\n 1. Insert";
	cout<<"\n 2. Preorder";
	cout<<"\n 3. Postorder";
	cout<<"\n 4. Inorder";
	cout<<"\n 5. Exit";
	cout<<"\n Enter choice: ";
	cin>>ch;
	
		switch(ch)
		{
			case 1: cout<<"\n Enter value : ";
					cin>>value;
					t1.insert(value);
					break;
					
			case 2: t1.preorder(t1.root);
					break;
					
			case 3: t1.postorder(t1.root);
					break;
				
			case 4: t1.inorder(t1.root);
					break;
					 
			case 5: return 0;
		}
	}while(ch!=5);
	return 0; 
}
		
