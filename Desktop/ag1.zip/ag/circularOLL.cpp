#include<iostream>
#include<cstdlib>
using namespace std;

class CirOSLLNode{

 public:
  int info;
  CirOSLLNode *next;

CirOSLLNode(){
info=0;
next=NULL;
}

CirOSLLNode(int val,CirOSLLNode* ptr){
info=val;
next=ptr;
}

};


class CirOSLL{

CirOSLLNode* head=NULL;
CirOSLLNode* tail=NULL;

public:

int search(int var){

CirOSLLNode* p=head;
int count1=0;
while(p!=NULL){
    count1++;
	if(p->info==var)return count1;
	p=p->next;
	}

return -1;

}


void traverse(){

CirOSLLNode* p=head;
cout<<"\nList-> ";
if(head==NULL){cout<<"Empty List\n";}
else if(head==tail)cout<<p->info<<" ";
else {
	while(p->next!=head){
	cout<<p->info<<"  ";
	p=p->next;
	}
      cout<<p->info<<endl;
}

}


void del(int);
void add(int);

};

void CirOSLL::del(int val){
	if(head==NULL)cout<<"\nNo element deleted.";
	else if(head==tail){
		if(head->info==val){
		delete head;
 		head=NULL;
		tail=NULL;
		}
	}
	else{
	CirOSLLNode* cur=head;
	CirOSLLNode* prev=head;
	while(cur!=NULL&&cur->info!=val){
		if(cur!=prev)prev=prev->next;
		cur=cur->next;
	}

	if(cur==NULL)cout<<"No element is equal to "<<val<<" in the list!\n";
	else if(cur==head){
        	head=head->next;
		delete cur;
		cur=NULL;
                tail->next=head;
	}
	else if(cur==tail){
        	delete tail;
        	tail=prev;
                tail->next=head;

	}
	else{
		prev->next=cur->next;
		delete cur;
	    }
	}
	traverse();
}


void CirOSLL::add(int val){

CirOSLLNode* node=new CirOSLLNode(val,NULL);

if(head==NULL)
{
head=tail=node;
head->next=tail;
tail->next=head;
}

else if(head!=NULL){

CirOSLLNode* p=head;

if(node->info<=head->info){
 	node->next=head;
	head=node;
        tail->next=head;
}
else if(node->info > tail->info){
	tail->next=node;
	tail=node;
	tail->next=head;
	}
else{
    	CirOSLLNode* q=p->next;
	while(q!=NULL){

		if(node->info >= p->info && node->info < q->info){
			node->next=q;
 			p->next=node;
            break;
		}
        p=p->next;
        q=q->next;
	}
}

}

traverse();

}

int main(){

CirOSLL list;
char ch,ch1;
int ele,pos;

do{
	cout<<"\nMENU::\n1)Add Element.\n2)Delete Element.\n3)Traverse.\n4)search element.\n5)Exit.\n";
	cout<<"\nEnter your choice: ";
	cin>>ch1;
	switch(ch1){
		case '1': cout<<"\nEnter element to add: ";
	                  cin>>ele;
	        	  list.add(ele);
	 		  break;
		case '2': cout<<"\nEnter element to delete: ";
	                  cin>>ele;
	                  list.del(ele);
	 		  break;
		case '3':list.traverse();
			  break;
		case '4':cout<<"\nEnter ele to search: ";
		          cin>>ele;
		          pos=list.search(ele);
		          if(pos!=-1)cout<<"\nElement found at position: "<<pos;
		          else cout<<"\nElement not found.";
			  break;
		case '5':exit(0);

		default: cout<<"\nWrong choice!!";

		}
}while(true);

return 0;

}


