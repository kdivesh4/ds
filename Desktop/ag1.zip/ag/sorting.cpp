#include<iostream>
using namespace std;

void bubsort(int ar[],int n){
	int i,j,temp;
	for(i=0;i<(n-1);i++)
	{
	 for(j=0;j<(n-i-1);j++)
	 {
		if(ar[j]>ar[j+1])
		{
		temp=ar[j];
		ar[j]=ar[j+1];
		ar[j+1]=ar[j];
	 	}
	 }cout<<"after sorting";
	for(int i=0;i<n;i++)
	 {
		cout<<ar[i]<< " " ; 
		cout<<endl;
	 }
 	}
 }
void insort(int ar[],int n)
{
	int i,j,temp;
	for(i=0;i<n;i++)
	{
	 temp=ar[i];
	 j=j-1;
	 while(temp<ar[j] && (j>=0))
	 {
		ar[j+1]=ar[j];
		j=j-1;
	 }
	 ar[j+1]=temp;
	 for(i=0;i<n;i++)
	 {
		cout<<"sorted using insort  : "<<ar[i]<< " " ;
	 }
	}
}

int main() {
	int i,j,n,ar[10],ch,x=1;
	cout<<"Enter the number of elements\n";
	cin>>n;
	cout<<"Enter "<< n <<" elements\n";
	for(i=0;i<n;i++)
	{	cin>>ar[i]; }
	while(x==1) {
	cout<<"Choose the sorting option\n";
	cout<<"1. bubsort\n2. insort\n";
	cin>>ch;
	switch(ch) {
	case 1: {
			bubsort(ar,n);
			x=0;
		}
		break;
	case 2: {
			insort(ar,n);
			x=0;
		}		
		break;

	default: {
			cout<<"invalid option\n";
			x=1;
			}
		}
	}
	return 0;
}

