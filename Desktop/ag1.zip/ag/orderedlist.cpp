#include<iostream>
#include<cstdlib>
using namespace std;

class IntSLLNode{

 public:
  int info;
  IntSLLNode *next;

IntSLLNode(){
info=0;
next=NULL;
}

IntSLLNode(int val,IntSLLNode* ptr){
info=val;
next=ptr;
}

};


class IntSLL{

IntSLLNode* head=NULL;
IntSLLNode* tail=NULL;

public:

int search(int var){

IntSLLNode* p=head;
int count1=0;
while(p!=NULL){
    count1++;
	if(p->info==var)return count1;
	p=p->next;
	}

return -1;

}


void traverse(){

IntSLLNode* p=head;
cout<<"\nList-> ";
if(p!=NULL){

	while(p!=tail->next){
	cout<<p->info<<"  ";
	p=p->next;
	}
}
else cout<<"Empty";
}


void del(int);
void add(int);

};

void IntSLL::del(int val){
	if(head==NULL)cout<<"\nNo element deleted.";
	else if(head==tail){
		if(head->info==val){
		delete head;
 		head=NULL;
		tail=NULL;
		}
	}
	else{
	IntSLLNode* cur=head;
	IntSLLNode* prev=head;
	while(cur!=NULL&&cur->info!=val){
		if(cur!=prev)prev=prev->next;
		cur=cur->next;
	}

	if(cur==NULL)cout<<"No element is equal to "<<val<<" in the list!\n";
	else if(cur==head){
        	head=head->next;
		delete cur;
		cur=NULL;
	}
	else if(cur==tail){
        	delete tail;
        	tail=prev;

	}
	else{
		prev->next=cur->next;
		delete cur;
	    }
	}
	traverse();
}


void IntSLL::add(int val){

IntSLLNode* node=new IntSLLNode(val,NULL);

if(head==NULL)
   head=tail=node;

else if(head!=NULL){

IntSLLNode* p=head;

if(node->info<=head->info){
 	node->next=head;
	head=node;
}
else if(node->info > tail->info){
	tail->next=node;
	tail=node;
	}
else{
    IntSLLNode* q=p->next;
	while(q!=NULL){

		if(node->info >= p->info && node->info < q->info){
			node->next=q;
 			p->next=node;
            break;
		}
        p=p->next;
        q=q->next;
	}
}

}

traverse();

}

int main(){

IntSLL list;
char ch,ch1;
int ele,pos;

do{
	cout<<"\nMENU::\n1)Add Element.\n2)Delete Element.\n3)Traverse.\n4)search element.\n5)Exit.\n";
	cout<<"\nEnter your choice: ";
	cin>>ch1;
	switch(ch1){
		case '1': cout<<"\nEnter element to add: ";
	                  cin>>ele;
	        	  list.add(ele);
	 		  break;
		case '2': cout<<"\nEnter element to delete: ";
	                  cin>>ele;
	                  list.del(ele);
	 		  break;
		case '3':list.traverse();
			  break;
		case '4':cout<<"\nEnter ele to search: ";
		          cin>>ele;
		          pos=list.search(ele);
		          if(pos!=-1)cout<<"\nElement found at position: "<<pos;
		          else cout<<"\nElement not found.";
			  break;
		case '5':exit(0);

		default: cout<<"\nWrong choice!!";

		}
}while(true);

return 0;

}
